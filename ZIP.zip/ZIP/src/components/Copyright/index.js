import React from "react";
import "./index.sass";

const SalveCopyright = () => {
  return <div id="copyright">Made with ❤ by Salve Agency</div>;
};

export default SalveCopyright;
